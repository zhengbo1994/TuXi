﻿/// <reference path="../openLayer/ol.js" />
/**
 基于OpenLayer的矢量编辑工具
 */
(function ($) {
    $.fn.mapVectorEditorCtl = function (settings) {
        //集合扩展
        Array.prototype.indexOfEx = function (feature) {
            for (var i = 0; i < this.length; i++) {
                var id1 = this[i].getId();
                var id2 = feature.getId();
                if (id1 == id2) {
                    return i;
                }
            }
            return -1;
        };
        Array.prototype.removeEx = function (feature) {
            try {
                var index = this.indexOfEx(feature);
                if (index > -1) {
                    this.splice(index, 1);
                }
            }
            catch (e) {
            }
        };
        //默认选项
        var defaluts = {
            //地图底图数据源集合
            baseLayerList: null,
            //iTelluro地图服务集合
            iTelluroLayerList: null,
            //矢量数据结合
            vectorDataList: null,
            //矢量图层集合
            vectorLayerList: null,
            //地图控件宽高
            mapHeight: 400,
            mapWidth: 800,
            //边界拐点坐标
            boundWKT: null,
            center: [118.0415, 36.4482],
            zoom: 3,
        };
        $.extend(defaluts, settings);

        //设置样式
        var me = $(this);
        var id = me.attr("id");
        if (id == null || id == "") {
            id = "mapVectorEditor" + new Date().getTime();
            me.attr("id", id);
        }
        me.height(defaluts.mapHeight);
        me.css({
            width: '100%',
            //height:$(window).height()-me.offset().top
        });
        //地图上的显示模块的Html
        var html = '<div class="ui-layout">' +
            '           <a class="sidebar-showon" title="展开"><i class="fa fa-forward" style="color: #ccc;"></i></a>' +
            '           <div class="ui-layout-west">' +
            '               <a class="sidebar-shutup" title="收缩"><i class="fa fa-backward" style="color: #ccc;"></i></a>' +
            '               <div class="panel-Title"><span>图层树信息</span><button class="btn btn-default add-layer" title="添加图层"><i class="fa fa-plus"></i></button></div>' +
            '               <div id="itemTree"></div>' +
            '           </div>' +
            '           <div class="map_container">' +
			'               <div class="mapDiv"></div> ' +
			'               <div class="mapControllerBtn"> ' +
            '                   <span class="map_point" data-toggle="tooltip" data-placement="bottom" title="点"><i class="fa fa-dot-circle-o"></i></span>' +
            '                   <span class="map_line" data-toggle="tooltip" data-placement="bottom" title="线"><i class="ti-layout-line-solid"></i></span>' +
			'                   <span class="map_polygon" data-toggle="tooltip" data-placement="bottom" title="多边形"><i class="ti-cloud"></i></span>' +
   			'                   <span class="map_rect" data-toggle="tooltip" data-placement="bottom" title="矩形"><i class="fa fa-square-o"></i></span>' +
           	'                   <span class="map_circle" data-toggle="tooltip" data-placement="bottom" title="圆"><i class="fa fa-circle-o"></i></span>' +
			'                   <span class="map_select" data-toggle="tooltip" data-placement="bottom" title="点选要素"><i class="ti-hand-point-up"></i></span>' +
            '                   <span class="map_boxselect" data-toggle="tooltip" data-placement="bottom" title="框选要素"><i class="ti-layout-width-default-alt"></i></span>' +
			'                   <span class="map_edit" data-toggle="tooltip" data-placement="bottom" title="编辑要素(按住Alt键删除)"><i class="ti-pencil-alt"></i></span>' +
            '                   <span class="map_editend" data-toggle="tooltip" data-placement="bottom" title="结束编辑"><i class="ti-check"></i></span>' +
            '                   <span class="map_cut" data-toggle="tooltip" data-placement="bottom" title="裁剪"><i class="ti-cut"></i></span>' +
			'                   <span class="map_delete" data-toggle="tooltip" data-placement="bottom" title="删除要素"><i class="ti-trash"></i></span>' +
            '                   <span class="map_move" data-toggle="tooltip" data-placement="bottom" title="移动要素"><i class="ti-move"></i></span>' +
			'                   <span class="map_editcorol" data-toggle="tooltip" data-placement="bottom" title="修改颜色"><i class="ti-pencil-alt2"></i></span>' +
            '                   <span class="map_editcoroller" data-toggle="tooltip" data-placement="bottom" title="样式设置"><i class="ti-brush-alt"></i></span>' +
            '                   <span class="map_set" data-toggle="tooltip" data-placement="right" title="设置"><i class="ti-settings"></i></span>' +
			'               </div>' +
			'               <div class=" map_zoom ol-zoom ol-unselectable ol-control"><button data-toggle="tooltip" data-placement="top" title="放大" type="button" class="ol-zoom-in map-zoom-in" id="zoomIn"><i class="ti-plus"/></button><button data-toggle="tooltip" data-placement="right" title="缩小" type="button" class="ol-zoom-out map-zoom-out"><i class="ti-minus"/></button></div>' +
            '               <div class="set_box"></div>' +
            '           </div>' +
            '       </div>'
        me.html('');
        me.append(html);
        var count = me.find("#popup").length;
        if (count == 0) {
            var html = '<div class="ol-popup none" id="popup" style="display:none;">' + '<div id="popup-content"></div></div>';
            me.append(html);
        }
        html = null;
        if (defaluts.baseLayerList == null) {
            return;
        }

        //地图的全局变量
        var map = null, polyDraw, pointSelect, polyModify, polyDrag, boxSelect, snapTool, snapLayer;
        var tipLayer = null;
        var baseMap = defaluts.baseLayerList[0];
        var baseZJ = defaluts.baseLayerList[1];
        //选中的Feature
        var selectFeatures = [];
        //要素备份;
        var featuresBak = [];
        //图层数据源
        var vectorDrawSource = new ol.source.Vector({
            wrapX: false
        });
        var vectorDrawLayer = new ol.layer.Vector({
            source: vectorDrawSource
        });

        var vectorPointSource = new ol.source.Vector({
            wrapX: false
        });
        var vectorPonintLayer = new ol.layer.Vector({
            source: vectorPointSource
        });
        //其他变量
        var isSmooth = true;
        var toolType = "Polygon";
        var lineWidth = 3;
        var wgs84Sphere = new ol.Sphere(6378136.49);

        //获取地图控件自定义的高度值
        var mapheight = defaluts.mapHeight;
        //设置地图容器
        var mapDiv = me.find("div.mapDiv");

        //动态的设置地图的高度
        mapDiv.css({
            //height: mapheight
            height: $(window).height() - 60
        });

        //生成图层树节点
        var treeData = [];
        var dtNode = {
            id: 'baseLayer',
            text: '底图',
            value: 'baseLayer',
            parentnodes: '0',
            checkstate: 1,
            showcheck: true,
            isexpand: false,
            complete: true,
            hasChildren: false,
            ChildNodes: []
        };
        treeData.push(dtNode);
        var bzNode = {
            id: 'zjLayer',
            text: '底图注记',
            value: 'zjLayer',
            parentnodes: '0',
            checkstate: 1,
            showcheck: true,
            isexpand: false,
            complete: true,
            hasChildren: false,
            ChildNodes: []
        };
        treeData.push(bzNode);
        if (defaluts.boundWKT && defaluts.boundWKT.length > 0) {
            var cutNode = {
                id: 'cutLayer',
                text: '剪切范围',
                value: 'cutLayer',
                parentnodes: '0',
                checkstate: 1,
                showcheck: true,
                isexpand: false,
                complete: true,
                hasChildren: false,
                ChildNodes: []
            };
            treeData.push(cutNode);
        };
        if (defaluts.iTelluroLayerList && defaluts.iTelluroLayerList.length > 0) {
            for (var i = 0; i < defaluts.iTelluroLayerList.length; i++) {
                var node = {
                    id: defaluts.iTelluroLayerList[i].dataserverkey,
                    text: defaluts.iTelluroLayerList[i].dataserverkey,
                    value: defaluts.iTelluroLayerList[i].dataserverkey,
                    parentnodes: '0',
                    checkstate: 1,
                    showcheck: true,
                    isexpand: false,
                    complete: true,
                    hasChildren: false,
                    ChildNodes: []
                };
                treeData.push(node);
            };
        };
        if (defaluts.vectorLayerList && defaluts.vectorLayerList.length > 0) {
            for (var i = 0; i < defaluts.vectorLayerList.length; i++) {
                var node = {
                    id: defaluts.vectorLayerList[i].layerName,
                    text: defaluts.vectorLayerList[i].layerName,
                    value: defaluts.vectorLayerList[i].layerName,
                    parentnodes: '0',
                    checkstate: 1,
                    showcheck: true,
                    isexpand: false,
                    complete: true,
                    hasChildren: false,
                    ChildNodes: []
                };
                treeData.push(node);
            };
        };
        //加载图层树
        function GetTree() {
            var item = {
                height: defaluts.mapHeight - $("#itemTree").offset().top,
                showcheck: true,
                data: treeData,
                oncheckboxclick: function (item, status) {
                    var layerName = item.value;
                    var maplayers = map.getLayers().getArray();
                    maplayers.forEach(function (layer) {
                        if (layer.get("name") == layerName) {
                            if (status == 0) {
                                layer.setVisible(false);
                            } else {
                                layer.setVisible(true);
                            }
                        }
                    });
                }
            };
            //初始化
            $("#itemTree").treeview(item);
        };
        GetTree();
        //图层树显示隐藏
        var treeWidth = $(".ui-layout").find(".ui-layout-west").width();
        $(".ui-layout").find(".sidebar-shutup").click(function () {
            $(".ui-layout").find(".ui-layout-west").animate({ marginLeft: -(treeWidth + treeWidth * 0.1) }, 300);
            $(".ui-layout").find(".sidebar-showon").show();
            mapDiv.width(me.width());
            map.updateSize();
        });
        $(".ui-layout").find(".sidebar-showon").click(function () {
            $(".ui-layout").find(".ui-layout-west").animate({ marginLeft: 0 }, 300);
            $(".ui-layout-west").width(me.width() * 0.1);
            $(".ui-layout").find(".sidebar-showon").hide();
            setTimeout(function () {
                mapDiv.width(me.width() * 0.9);
                map.updateSize();
            }, 300);
        });
        //添加图层弹窗
        $(".ui-layout").find(".add-layer").click(function () {
            var _tab = '<div class="tabWraper">' +
                            '<ul class="nav nav-tabs" style="border-bottom: 1px solid #ddd;">' +
                                '<li><input type="radio" value="1" name="layer" checked=checked /><label>iTelluro服务<label/></li>' +
                                '<li><input type="radio" value="2" name="layer" /><label>GeoJSON矢量数据<label/></li>' +
                                '<li><input type="radio" value="3" name="layer" /><label>WMS服务<label/></li>' +
                            '</ul>' +
                       '</div>' +
                       '<div class="tab-content" style="padding:10px;"></div>';
            var tabContent1 = '<div class="tab-item"><label for="key-name"><i>服</i><i>务</i><i>key</i><i>名</i><i>称：</i></label><input type="text" id="key-name"/></div>' +
                              '<div class="tab-item"><label for="key-url"><i>服</i><i>务</i><i>地</i><i>址：</i></label><input type="text" id="key-url"/></div>' +
                              '<div class="tab-item"><label for="zero-grade"><i>零</i><i>级</i><i>大</i><i>小：</i></label><input type="number" id="zero-level-size"/></div>' +
                              '<div class="tab-item"><label for="key-url"><i>图</i><i>层</i><i>透</i><i>明</i><i>度：</i></label><input type="number" id="layer-opacity" value="1.0"/></div>';
            var tabContent2 = '<div class="tab-item"><label class="geo" for="key-name"><i>名</i><i>称：</i></label><input type="text" id="key-name"/></div>' +
                              '<div class="tab-item"><label class="geo" for="key-url"><i>路</i><i>径：</i></label><input type="text" id="key-url"/></div>';
            layer.open({
                type: 1,
                skin: 'layui-layer-rim',
                area: ['345px', '350px'],
                btn: ['确定', '取消'],
                title: '添加图层',
                content: _tab,
                success: function (layero, index) {//弹出回调，切换选项
                    var _radio = layero.find(".nav-tabs li").find("input[type='radio']");
                    var tabContent = layero.find(".tab-content");
                    showCurrentTab();
                    _radio.click(function () {
                        tabContent.html("");
                        showCurrentTab();
                    });
                    function showCurrentTab() {//单选切换相应表单的函数
                        for (var i = 0; i < _radio.length; i++) {
                            var radioState = $(_radio[i]).prop("checked");
                            var radioValue = $(_radio[i]).attr("value");
                            if (radioState) {
                                if (radioValue == 1) {
                                    tabContent.append(tabContent1);
                                } else if (radioValue == 2) {
                                    tabContent.append(tabContent2);
                                } else if (radioValue == 3) {
                                    console.log("待开发");
                                };
                            };
                        };
                    };
                },
                yes: function (index, layero) {//完成后回调，提交
                    var keyName = layero.find("#key-name").val();
                    var keyUrl = layero.find("#key-url").val();
                    var zeroLevelSize = layero.find("#zero-level-size").val();
                    var layerOpacity = layero.find("#layer-opacity").val();
                    var _ID = uuid();
                    var newNode = {
                        id: _ID,
                        text: keyName,
                        value: keyName,
                        parentnodes: '0',
                        checkstate: 1,
                        showcheck: true,
                        isexpand: false,
                        complete: true,
                        hasChildren: false,
                        ChildNodes: []
                    };
                    function creatNode() {
                        var _input = layero.find(".tab-content").find("input");
                        for (var i = 0; i < _input.length; i++) {//验证是否有未填项
                            var _val = $(_input[i]).val();
                            if (!_val) {
                                $(_input[i]).focus().css("outline-color", "red");
                                return;
                            } else {
                                $(_input[i]).css("outline-color", "");
                            };
                        };
                        for (var j = 0; j < treeData.length;j++){
                            if (keyName === treeData[j].text) {//验证是否重名
                                $(_input[0]).focus().css("outline-color", "red").val("命名重复，请重设图层名称！");
                                return;
                            } else {
                                $(_input[0]).css("outline-color", "");
                            };
                        };
                        treeData.push(newNode);
                        GetTree();
                        layer.close(index);
                    };
                    if (layerOpacity < 0) {
                        layerOpacity = 0;
                    } else if (layerOpacity > 1) {
                        layerOpacity = 1;
                    };
                    var currentRadioValue = layero.find(".nav-tabs li").find("input[type='radio']:checked").attr("value");
                    if (currentRadioValue == 1) {//iTelluro服务
                        creatNode();//生成左侧图层树节点
                        var layers = [{ dataserverkey: keyName, url: keyUrl, tilesize: 512, zerolevelsize: zeroLevelSize, opacity: layerOpacity }];
                        addiTelluroLayer(layers);
                    } else if (currentRadioValue == 2) {//GeoJSON矢量数据
                        creatNode();//生成左侧图层树节点
                        var layers = [{ layerName: keyName, geoJsonUrl: keyUrl }];
                        addVectorLayer(layers);
                    } else if (currentRadioValue == 3) {
                        console.log("待开发");
                    };
                }
            });
        });

        /** 按钮事件开始**/
        /** 画点**/
        var map_point = me.find(".map_point");
        map_point.click(function () {
            toolType = "Point";
            drawShapes();
        });

        /** 画线**/
        var map_line = me.find(".map_line");
        map_line.click(function () {
            toolType = "LineString";
            drawShapes();
        });

        /** 画多边形**/
        var map_polygon = me.find(".map_polygon");
        map_polygon.click(function () {
            toolType = "Polygon";
            drawShapes();
        });

        /** 画矩形**/
        var map_rect = me.find(".map_rect");
        map_rect.click(function () {
            toolType = "Box";
            drawShapes();
        });

        /** 画圆**/
        var map_circle = me.find(".map_circle");
        map_circle.click(function () {
            toolType = "Circle";
            drawShapes();
        });

        //画形状
        function drawShapes() {
            removeInteraction();
            clearPointLayer();
            reSet();
            if (toolType == "Box") {
                var geoFun = ol.interaction.Draw.createBox();
                polyDraw = new ol.interaction.Draw({
                    source: vectorDrawSource,
                    type: "Circle",
                    geometryFunction: geoFun
                });
            } else {
                polyDraw = new ol.interaction.Draw({
                    source: vectorDrawSource,
                    type: toolType
                });
            }
            if (toolType == "Circle") {
                polyDraw.on('drawstart', function (event) {
                    var feat = event.feature;
                    var geometry = feat.getGeometry();
                    var listener = geometry.on('change', function (ev) {
                        var radius = geometry.getRadius();
                        //var sourceProj = map.getView().getProjection();
                        var center = geometry.getCenter();
                        var last = geometry.getLastCoordinate();
                        //center = ol.proj.transform(center, sourceProj, 'EPSG:4326');
                        //last = ol.proj.transform(last, sourceProj, 'EPSG:4326');
                        var length = wgs84Sphere.haversineDistance(center, last);
                        //length = wgs84Sphere.haversineDistance([108.8857,31.9726], [119.2216,40.9032]);
                        if (length > 100) {
                            length = (Math.round(length / 1000 * 100) / 100)+ 'km';
                        } else {
                            length = (Math.round(length * 100) / 100) +'m';
                        }
                        //var line = new ol.geom.LineString();
                        //line.setCoordinates([center, last]);

                        //var lineLen = line.getLength(line);
                        var popup_element = me.find("#popup")[0];
                        var popup_content = me.find("#popup-content")[0];
                        popup_element.style.display = 'block';
                        popup_content.innerHTML = length;
                        if (!tipLayer) {
                            tipLayer = new ol.Overlay(({
                                element: popup_element,
                                autoPan: true,
                                autoPanAnimation: {
                                    duration: 250
                                },
                                id:"tipLayer"
                            }));
                            map.addOverlay(tipLayer);
                        }
                        tipLayer.setPosition(center);
                    });
                });
            }
            polyDraw.on('drawend', function (event) {
                //设置圆滑默认样式
                var feat = event.feature;
                addFeature(feat);
                if (tipLayer) {
                    tipLayer.setPosition(null);
                }
            });
            map.addInteraction(polyDraw);
            addSnapTool();
        };

        /** 选择多边形**/
        var map_select = me.find(".map_select");
        map_select.click(function () {
            removeInteraction();
            pointSelect = new ol.interaction.Select({
                layers: [vectorDrawLayer],
                toggleCondition: ol.events.condition.click
            });
            pointSelect.on('select', function (event) {
                //设置选中
                selectFeatures = null;
                selectFeatures = event.selected;
                selectFeature();
                map.render();
            });
            map.addInteraction(pointSelect);
            map.render();
        });

        var map_boxselect = me.find(".map_boxselect");
        map_boxselect.click(function () {
            removeInteraction();
            boxSelect = new ol.interaction.DragBox({
            });
            boxSelect.on('boxend', function (event) {
                //设置选中
                selectFeatures = null;
                selectFeatures = [];
                var extent = boxSelect.getGeometry().getExtent();
                vectorDrawSource.forEachFeatureIntersectingExtent(extent, function (feature) {
                    selectFeatures.push(feature);
                });
                selectFeature();
                map.render();
            });
            map.addInteraction(boxSelect);
            map.render();
        });

        /** 编辑多边形**/
        var map_edit = me.find(".map_edit");
        map_edit.click(function () {
            //if (polyDraw) {
            //    map.removeInteraction(polyDraw);
            //}
            removeInteraction();
            if (!selectFeatures || selectFeatures.length <= 0) {
                return;
            }
            polyModify = new ol.interaction.Modify({
                features: new ol.Collection(selectFeatures)
            });
            polyModify.on('modifystart', function (event) {
                console.log(event);
            });
            polyModify.on('modifyend', function (event) {
                console.log(event);
                //画点图层
                var features = event.features.getArray();
                var isClear = true;
                if (tipLayer) {
                    tipLayer.setPosition(null);
                }
                for (var i = 0; i < features.length; i++) {
                    if (i != 0) {
                        isClear = false;
                    }
                    var geometry = features[i].getGeometry();
                    var coords = null;
                    try {
                        coords = geometry.getCoordinates();
                    } catch (e) {

                    }
                    var geoType = geometry.getType();
                    if (geoType == "Polygon") {
                        addPointToPointLayer(coords[0], isClear);
                    } else if (geoType == "LineString") {
                        addPointToPointLayer(coords, isClear);
                    } else if (geoType == "Point") {
                        addPointToPointLayer([[coords[0], coords[1]]], isClear);
                    } else if (geoType == "Circle" && geometry instanceof ol.geom.Circle) {
                        var center = geometry.getCenter();
                        addPointToPointLayer([center], isClear);
                    }
                }
            });
            map.addInteraction(polyModify);
            addSnapTool();
        });

        /** 结束编辑多边形**/
        var map_editend = me.find(".map_editend");
        map_editend.click(function () {
            removeInteraction();
            clearPointLayer();
            //画点图层
            if (selectFeatures && selectFeatures.length > 0) {
                for (var i = 0; i < selectFeatures.length; i++) {
                    var geometry = selectFeatures[i].getGeometry();
                    var coords = null;
                    try {
                        coords = geometry.getCoordinates();
                    } catch (e) {

                    }
                    var geoType = geometry.getType();
                    var smoothened = [];
                    if (geoType == "Polygon") {
                        smoothened = getCurvePoints(convertToSmoothPoint(coords[0]), 0.5, 20, false);//makeSmooth(coords[0], 3);
                        geometry.setCoordinates([convertToGeometryPoint(smoothened)]);
                    } else if (geoType == "LineString") {
                        smoothened = getCurvePoints(convertToSmoothPoint(coords), 0.5, 20, false);
                        geometry.setCoordinates(convertToGeometryPoint(smoothened));
                    }
                }
            }
            selectFeatures = null;
            reSetFromBak();
        });

        /** 删除多边形**/
        var map_delete = me.find(".map_delete");
        map_delete.click(function () {
            removeInteraction();
            clearPointLayer();
            if (!selectFeatures || selectFeatures.length <= 0) {
                return;
            }

            for (var i = 0; i < selectFeatures.length; i++) {
                vectorDrawSource.removeFeature(selectFeatures[i]);
                featuresBak.removeEx(selectFeatures[i]);
            }
            selectFeatures = null;
        });

        /** 移动多边形**/
        var map_move = me.find(".map_move");
        map_move.click(function () {
            removeInteraction();
            clearPointLayer();
            selectFeatures = null;
            reSetFromBak();
            if (!polyDrag) {
                polyDrag = new vectorDrag.Drag();
            }
            map.addInteraction(polyDrag);
        });

        /** 剪切多边形**/
        var map_cut = me.find(".map_cut");
        map_cut.click(function () {
            removeInteraction();
            clearPointLayer();
            selectFeatures = null;
            reSetFromBak();
            if (!defaluts.boundWKT || defaluts.boundWKT.length <= 0 || featuresBak.length <= 0) {
                return;
            }
            var wktJSTSReader = new jsts.io.WKTReader();
            var parser = new jsts.io.OL3Parser();
            var wktOLReader = new ol.format.WKT();
            var tmpFeatures = featuresBak;
            featuresBak = [];
            vectorDrawSource.clear();
            for (var j = 0; j < defaluts.boundWKT.length; j++) {
                var bound = wktJSTSReader.read(defaluts.boundWKT[j]);
                for (var i = 0; i < tmpFeatures.length; i++) {
                    var tmpCircle = null;
                    if (tmpFeatures[i].getGeometry() instanceof ol.geom.Circle) {
                        tmpCircle = tmpFeatures[i];
                        tmpFeatures[i] = createCircle(tmpFeatures[i]);
                    }
                    var featureWKT = wktOLReader.writeFeature(tmpFeatures[i]);
                    var featuretmmp = wktJSTSReader.read(featureWKT);
                    var isV = featuretmmp.isValid();
                    if (!isV) {
                        featuresBak.push(tmpFeatures[i]);
                        vectorDrawSource.addFeature(tmpFeatures[i]);
                        continue;
                    }
                    var cutFTS = bound.intersection(featuretmmp);
                    if (!cutFTS.isEmpty()) {
                        if (bound.contains(featuretmmp)) {
                            if (tmpCircle) {
                                featuresBak.push(tmpCircle);
                                vectorDrawSource.addFeature(tmpCircle);
                            } else {
                                featuresBak.push(tmpFeatures[i]);
                                vectorDrawSource.addFeature(tmpFeatures[i]);
                            }
                        }
                        else {
                            var num = cutFTS.getNumGeometries();
                            for (var k = 0; k < num; k++) {
                                var geo = cutFTS.getGeometryN(k);
                                var geoType = geo.getGeometryType();
                                if (geoType == 'Polygon' || geoType == "MultiPolygon" || geoType == "LineString" || geoType == "Point") {
                                    var feat = new ol.Feature({
                                        geometry: parser.write(geo)
                                    });
                                    feat.setStyle(tmpFeatures[i].getStyle());
                                    var id = uuid();
                                    feat.setId(id);
                                    featuresBak.push(feat);
                                    vectorDrawSource.addFeature(feat);
                                }
                            }
                        }
                    }
                    console.log(cutFTS);
                }
            }

        });

        /** 初始化颜色框**/
        var map_editcorol = me.find('.map_editcorol');
        var colorpick = map_editcorol.colpick({
            onSubmit: function (hsb, hex, rgb, el, bySetColor) {
                $(el).removeClass("active").find("i").css("color", "");
                if (!selectFeatures || selectFeatures.length <= 0) {
                    $(el).colpickHide();
                    return;
                }

                for (var i = 0; i < selectFeatures.length; i++) {
                    var feat = selectFeatures[i];
                    var geometry = feat.getGeometry();
                    var geoType = geometry.getType();
                    var style = feat.getStyle();
                    var color = style.getFill().getColor();
                    var lineColor = style.getStroke().getColor();
                    var colorList = ol.color.asArray(color);
                    var cc = 'rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ' ,' + colorList[3] + ')';
                    var style1 = new ol.style.Style({
                        fill: new ol.style.Fill({
                            color: cc
                        }),
                        stroke: new ol.style.Stroke({
                            color: lineColor,
                            width: 1
                        })
                    });
                    if (geoType == "LineString") {
                        style1.getStroke().setColor(cc);
                        style1.getStroke().setWidth(lineWidth);
                    }
                    feat.setStyle(style1)
                }
                removeInteraction();
                clearPointLayer();
                selectFeatures = null;
                $(el).colpickHide();
            }
        });
        map_editcorol.click(function () {
            if (!colorpick) {
                return;
            }
            removeInteraction();
            if (!selectFeatures || selectFeatures.length <= 0) {
                return;
            }
            var feat = selectFeatures[0];
            var style = feat.getStyle();
            var geometry = feat.getGeometry();
            var geoType = geometry.getType();
            var color = style.getFill().getColor();
            if (geoType == "LineString") {
                color = style.getStroke().getColor();
            }
            var colorList = ol.color.asArray(color);
            colorpick.colpickSetColor({ r: colorList[0], g: colorList[1], b: colorList[2] })
        });
        $(".colpick").addClass("colpick-one");
        //取色框销毁函数
        function removeColpick() {
            var _colpick = $(".colpick.colpick_full");
            for (var i = 0; i < _colpick.length; i++) {
                if (!$(_colpick[i]).hasClass("colpick-one")) {
                    $(_colpick[i]).remove();
                }
            }
        };
        /** 样式设置框 **/
        var map_editcoroller = me.find('.map_editcoroller');
        map_editcoroller.click(function () {
            removeInteraction();
            var _table = '<div class="table-responsive" id="style-box" style="padding:5px;">' +
                            '<table class="table table-bordered" style="margin:0;">' +
                               '<thead>' +
                                   '<tr style="border-bottom:none;">' +
                                       '<th>ID</th><th>类别</th><th>线色</th><th>线宽</th><th>填充色</th><th>透明度</th><th>icon标注</th><th>有无边框</th><th>有无填充</th>' +
                                   '</tr>' +
                               '</thead>' +
                               '<tbody class="text-center">' +
                                   '<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>' +
                               '</tbody>' +
                            '</table>' +
		                 '</div>';
            layer.open({
                type: 1,
                skin: 'layui-layer-rim',
                area: ['850px', '350px'],
                btn: ['确定', '取消'],
                title: '样式设置',
                content: _table,
                success: function (layero, index) {
                    //获取可编辑对象并渲染表格
                    var $tr = '';
                    var $tbody = layero.find("#style-box").find("table").find("tbody");
                    $tbody.find("tr").remove();
                    var Features = vectorDrawSource.getFeatures();
                    if (Features.length > 0) {
                        for (var i = 0; i < Features.length; i++) {
                            var FeatureName = "";
                            var GeoType = Features[i].getGeometry().getType();
                            var style = Features[i].getStyle();
                            var Fid = Features[i].getId();
                            var FillColor = style.getFill().getColor();
                            var LineColor = style.getStroke().getColor();
                            var LineWidth = style.getStroke().getWidth();
                            var FillOpacity = 1;
                            if (FillColor) {
                                FillOpacity = parseFloat(FillColor.split(",")[3].split(")")[0]);
                            };
                            if (GeoType == "Point") {
                                FeatureName = "点";
                                var _icon = style.getImage();
                                var _iconProtoFn = Object.keys(_icon.constructor.prototype);
                                var _value = _iconProtoFn.indexOf("getSrc") > 0 ? _icon.getSrc() : "";
                                var _input = Fid == undefined ? "" : "<input type='text' placeholder='请输入icon路径' value='" + _value + "' title='" + _value + "' />";
                                $tr = '<tr>' +
                                         '<td class="Features-id"><span title="' + Fid + '">' + Fid + '</span></td>' +
                                         '<td class="Features-name">' + FeatureName + '</td>' +
                                         '<td></td><td></td><td></td><td></td>' +
                                         '<td class="point-icon">' + _input + '</td>' +
                                         '<td></td><td></td>' +
                                      '</tr>';
                            } else if (GeoType == "LineString") {
                                FeatureName = "线";
                                $tr = '<tr>' +
                                         '<td class="Features-id"><span title="' + Fid + '">' + Fid + '</span></td>' +
                                         '<td class="Features-name">' + FeatureName + '</td>' +
                                         '<td class="side-color"><div class="color-fix" style="background:' + LineColor + '"></div></td>' +
                                         '<td class="side-width"><input type="number" style="text-align:center;text-indent: 15px;" value="' + LineWidth + '"/></td>' +
                                         '<td></td><td></td><td></td><td></td><td></td>' +
                                      '</tr>';
                            } else if (GeoType == "Polygon" || GeoType == "Circle" || GeoType == "Box") {
                                if (GeoType == "Circle") {
                                    FeatureName = "圆";
                                } else {
                                    var Coordinates = Features[i].getGeometry().getCoordinates();
                                    FeatureName = Coordinates[0].length == 5 ? "矩形" : "多边形";
                                };
                                var _isSideColorBlock = LineWidth == 0 ? 'none' : 'block';
                                var _isSideColorXBlock = LineWidth == 0 ? 'block' : 'none';
                                var _isFillColorBlock = FillOpacity == 0 ? 'none' : 'block';
                                var _isFillColorXBlock = FillOpacity == 0 ? 'block' : 'none';
                                var _isSideChecked = LineWidth == 0 ? '' : 'checked="checked"';
                                var _isFillChecked = FillOpacity == 0 ? '' : 'checked="checked"';
                                $tr = '<tr>' +
                                         '<td class="Features-id"><span title="' + Fid + '">' + Fid + '</span></td>' +
                                         '<td class="Features-name">' + FeatureName + '</td>' +
                                         '<td class="side-color">' +
                                             '<div class="color-fix" style="background:' + LineColor + ';display:' + _isSideColorBlock + ';"></div>' +
                                             '<div class="color-fix-x" style="background:rgb(0,0,255);display:' + _isSideColorXBlock + ';width:100%;height:100%;"></div>' +
                                         '</td>' +
                                         '<td class="side-width"><input type="number" style="text-align:center;text-indent: 15px;" value="' + LineWidth + '"/></td>' +
                                         '<td class="fill-color">' +
                                             '<div class="color-fix" style="background:' + FillColor + ';display:' + _isFillColorBlock + ';"></div>' +
                                             '<div class="color-fix-x" style="background:rgba(255,255,0,0.8);display:' + _isFillColorXBlock + ';width:100%;height:100%;"></div>' +
                                         '</td>' +
                                         '<td class="fill-opacity"><input type="number" style="text-align:center;text-indent: 15px;" value="' + FillOpacity + '"/></td>' +
                                         '<td></td>' +
                                         '<td><input type="checkbox" value="side"' + _isSideChecked + '/></td>' +
                                         '<td><input type="checkbox" value="fill"' + _isFillChecked + '/></td>' +
                                      '</tr>';
                            };
                            $tbody.append($tr);
                        };
                    };
                    /** 初始化颜色框**/
                    var _colorTd = $tbody.find(".color-fix");
                    var colorpick = _colorTd.colpick({
                        onSubmit: function (hsb, hex, rgb, el, bySetColor) {
                            var _rgbA = $(el).css("background-color").split(",");
                            var A = 0;
                            var CC = '';
                            if (_rgbA.length == 4) {
                                A = parseFloat(_rgbA[3].split(")")[0]);
                            } else {
                                A = 1.0;
                            };
                            if ($(el).hasClass("side-color")) {
                                CC = 'rgb(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ')';
                            } else {
                                CC = 'rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ' ,' + A + ')';
                            };
                            $(el).css("background", CC);
                            $(el).colpickHide();
                        }
                    });
                    $(".colpick.colpick_full").css("z-index", "99999");
                    _colorTd.click(function () {
                        if (!colorpick) {
                            return;
                        };
                        var color = $(this).css("background-color");
                        var rgba = color.split(",");
                        var R = parseInt(rgba[0].split("(")[1]);
                        var G = parseInt(rgba[1]);
                        if (rgba.length == 4) {
                            var B = parseInt(rgba[2]);
                        } else {
                            var B = parseInt(rgba[2].split(")")[0]);
                        };
                        colorpick.colpickSetColor({ r: R, g: G, b: B });
                    });
                    //checkbox事件
                    $tbody.find("input[type='checkbox']").click(function () {
                        var _checkValue = $(this).attr("value");
                        var _isChecked = $(this).prop("checked");
                        var _sideColor = $(this).parent().siblings(".side-color");
                        var _sideWidth = $(this).parent().siblings(".side-width");
                        var _fillColor = $(this).parent().siblings(".fill-color");
                        var _fillOpacity = $(this).parent().siblings(".fill-opacity");
                        if (_checkValue === "side") {
                            checking(_sideColor, _sideWidth, 1, "side");
                        } else if (_checkValue === "fill") {
                            checking(_fillColor, _fillOpacity, 0.8, "fill");
                        };
                        function checking(Co,Wo,num,item) {
                            if (_isChecked == false) {
                                Co.find(".color-fix").hide().siblings(".color-fix-x").show();
                                Wo.find("input").val(0).attr("disabled",true);
                            } else {
                                Wo.find("input").val(num).removeAttr("disabled");
                                var _background = item === "fill" ? "rgba(255,255,0,0.8)" : "rgba(0,0,255,1.0)";
                                Co.find(".color-fix").show().css("background", _background).siblings(".color-fix-x").hide();
                            }
                        };
                    });
                },
                yes: function (index, layero) {//完成后回调，提交样式
                    var _item = layero.find(".layui-layer-content").find("table").find("tbody").find("tr");
                    for (var i = 0; i < _item.length; i++) {
                        var featureId = $(_item[i]).find(".Features-id>span").text();
                        var geoType = $(_item[i]).find(".Features-name").text();
                        var lineWidth = $(_item[i]).find(".side-width>input").val();
                        var lineColor = $(_item[i]).find(".side-color>div").css("background-color");
                        var fillColor = $(_item[i]).find(".fill-color>div").css("background-color");
                        var fillOpacity = $(_item[i]).find(".fill-opacity>input").val();
                        var pointIcon = $(_item[i]).find(".point-icon>input").val();
                        var sideCheck = $(_item[i]).find("input[value='side']");
                        var fillCheck = $(_item[i]).find("input[value='fill']");
                            
                        var _sideChecked = sideCheck.prop("checked");
                        var _fillChecked = fillCheck.prop("checked");
                        if (_sideChecked == false) {
                            lineColor = "rgba(0,0,255,0)";
                            lineWidth = 0;
                        };
                        if (_fillChecked == false) {
                            fillOpacity = 0;
                        };
                        if (fillColor) {
                            var _fillColor = fillColor.split(",");
                            var opacity = 1;
                            if (_fillColor.length == 4) {
                                opacity = parseFloat(_fillColor[3].split(")")[0]);
                            };
                            if (fillOpacity < 0) {
                                fillOpacity = 0;
                            } else if (fillOpacity > 1) {
                                fillOpacity = 1;
                            };
                            if (fillOpacity !== opacity) {
                                fillColor = 'rgba(' + parseInt(_fillColor[0].split("(")[1]) + ',' + parseInt(_fillColor[1]) + ',' + parseInt(_fillColor[2]) + ',' + fillOpacity + ')';
                            };
                        };
                        var Features = vectorDrawSource.getFeatures();
                        var features = Features[i];
                        if (features) {
                            var fId = features.getId();
                            var GeoType = features.getGeometry().getType();
                            var Style = new ol.style.Style({
                                fill: new ol.style.Fill({
                                    color: fillColor
                                }),
                                stroke: new ol.style.Stroke({
                                    color: lineColor,
                                    width: lineWidth
                                })
                            });
                            if (featureId == fId) {
                                if (GeoType == "Point") {
                                    if (pointIcon) {
                                        Style = new ol.style.Style({
                                            image: new ol.style.Icon({
                                                src: pointIcon,
                                                size: [30, 30],
                                                scale: 0.8
                                            }),
                                            fill: new ol.style.Fill({
                                                color: 'rgba(255,255,0,0.8)'
                                            }),
                                            stroke: new ol.style.Stroke({
                                                color: 'rgba(0, 0, 0, 0.8)',
                                                width: 1
                                            })
                                        });
                                    } else {
                                        Style = new ol.style.Style({
                                            fill: new ol.style.Fill({
                                                color: 'rgba(255,255,0,0.8)'
                                            }),
                                            stroke: new ol.style.Stroke({
                                                color: 'rgba(0,0,255,1.0)',
                                                width: 1
                                            }),
                                            image: new ol.style.Circle({
                                                radius: 3,
                                                stroke: new ol.style.Stroke({
                                                    color: 'rgba(0, 0, 0, 0.8)'
                                                }),
                                                fill: new ol.style.Fill({
                                                    color: 'rgba(255, 255, 0, 0.8)'
                                                })
                                            })
                                        });
                                    };
                                } else if (GeoType == "LineString") {
                                    Style.getStroke().setColor(lineColor);
                                    Style.getStroke().setWidth(lineWidth);
                                //} else if (GeoType == "Polygon" || GeoType == "Circle" || GeoType == "Box") {
                                //    features.setStyle(Style);
                                };
                                features.setStyle(Style);
                            };
                        };
                    };
                    layer.close(index);
                    map_editcoroller.removeClass("active").find("i").css("color", "");
                    removeColpick()
                },
                cancel: function () {
                    map_editcoroller.removeClass("active").find("i").css("color", "");
                    removeColpick()
                }
            });
        });

        /** 设置框 **/
        var map_set = me.find(".map_set");
        map_set.click(function () {
            removeInteraction();
            clearPointLayer();
            selectFeatures = [];
            reSetFromBak();
        });
        var set_box = me.find(".set_box");
        var setItems = '<div class="set_item">' +
                '            <label>圆&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;滑：</label>' +
                '            <div class="checkbox-wrap"><input type="checkbox" class="set_YH" checked="checked"/></div>' +
                '       </div>' +
                '       <div class="set_item">' +
                '            <label for="longitude">经&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;度：</label>' +
                '            <input type="text" id="longitude"/>' +
                '       </div>' +
                '       <div class="set_item">' +
                '            <label for="latitude">纬&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;度：</label>' +
                '            <input type="text" id="latitude"/>' +
                '       </div>' +
                '       <div class="set_item">' +
                '            <label for="longitude">icon路径：</label>' +
                '            <input type="text" id="icon-href" value="../Content/images/flag_red.png"/>' +
                '       </div>' +
                '       <div class="set_item">' +
                '            <button class="btn btn-default" id="btn_PointShow">显示</button>' +
                '       </div>';
        set_box.append(setItems);

        /** 圆滑事件 **/
        var set_YH = me.find(".set_YH");
        set_YH.click(function () {
            if (this.checked) {
                isSmooth = true;
            } else {
                isSmooth = false;
            }
        });

        /** 设置框显示按钮点击事件 **/
        var btn_PointShow = me.find("#btn_PointShow");
        btn_PointShow.click(function () {
            var longitude = me.find("#longitude").val();
            var latitude = me.find("#latitude").val();
            var pointIcon = me.find("#icon-href").val();
            if (!pointIcon) {
                me.find("#icon-href").focus().css("outline-color", "red").attr("placeholder","请输入正确icon路径！");
                return;
            } else {
                me.find("#icon-href").css("outline-color", "").removeAttr("placeholder");
            };
            //导航到该点
            if (longitude && latitude) {
                map.getView().animate({ center: [longitude, latitude], duration: 1500 });
            };
            //显示该点
            //var stylePonit = new ol.style.Style({
            //    image: new ol.style.Circle({
            //        radius: 4,
            //        stroke: new ol.style.Stroke({
            //            color: 'rgba(0, 0, 0, 0.8)'
            //        }),
            //        fill: new ol.style.Fill({
            //            color: 'rgba(255, 0, 0, 1.0)'
            //        })
            //    })
            //});
            var stylePonit = new ol.style.Style({
                fill: new ol.style.Fill({
                    color: 'rgba(255,255,0,0.8)'
                }),
                stroke: new ol.style.Stroke({
                    color: 'rgba(0,0,255,1.0)',
                    width: 1
                }),
                image: new ol.style.Icon({
                    src: pointIcon,
                    size: [30, 30],
                    scale:0.8
                })
            });
            var featurePonit = new ol.Feature();
            var geometryPonit = new ol.geom.Point();
            var id = uuid();
            featurePonit.setId(id);
            geometryPonit.setCoordinates([longitude, latitude]);
            featurePonit.setGeometry(geometryPonit);
            featurePonit.setStyle(stylePonit);
            featuresBak.push(featurePonit);
            vectorDrawSource.addFeature(featurePonit);
        });
        /** 按钮事件结束**/

        /** 初始化提示**/
        me.find("[data-toggle='tooltip']").tooltip();
        /** 地图上的控件点击切换样式 **/
        me.find(".mapControllerBtn>span").click(function () {
            var setBoxLeft = $(this).offset().left - $(".map_container").offset().left - 1;
            var setBoxTop = $(this).height() + 12;
            if ($(this).hasClass("map_set")) {
                me.find("#longitude").val("");
                me.find("#latitude").val("");
                if (!$(this).hasClass("active")) {
                    $(this).find("i").css("color", "#fff");
                    $(this).addClass("active").siblings().removeClass("active").find("i").css("color", "");
                    $(".map_container").find(".set_box").show().css({ left: setBoxLeft, top: setBoxTop });
                } else {
                    $(this).removeClass("active").find("i").css("color", "");
                    $(".map_container").find(".set_box").hide();
                };
            } else {
                $(this).addClass("active").siblings().removeClass("active");
                $(this).find("i").css("color", "#fff").parent().siblings().find("i").css("color", "");
                $(".map_container").find(".set_box").hide();
            };
        });
        //me.find('.map_editcorol').click(function () {
        //    if ($(this).hasClass("active")) {
        //        $(".colpick.colpick_full").show();
        //    } else {
        //        $(".colpick.colpick_full").hide();
        //    };
        //});

        /** 初始化加载地图  **/
        (function loadMap() {
            if (map != undefined) {
                var layers = map.getLayers().a;
                layers.forEach(function (e) {
                    map.removeLayer(e);
                });
            };
            var zjLayer = "";
            //底图
            map = NewWebTilesMap(mapDiv[0], baseMap.zoomlevel, 180, -180, -90, 90, baseMap.dataserverkey, baseMap.url, baseMap.tilesize, baseMap.zerolevelsize, 'baseLayer');
            //加注记
            zjLayer = new iTelluro().newItelluroLayer(baseZJ.dataserverkey, baseZJ.url, baseZJ.tilesize, baseZJ.zerolevelsize, 'zjLayer');
            zjLayer.setZIndex(2);
            map.addLayer(zjLayer);
            vectorDrawLayer.setZIndex(100);
            map.addLayer(vectorDrawLayer);
            vectorPonintLayer.setZIndex(101);
            map.addLayer(vectorPonintLayer);

            initMapControl();
            //加载自定义数据
            addDrawDataFeatrues(defaluts.vectorDataList);
            //加载自定义图层
            addiTelluroLayer(defaluts.iTelluroLayerList);
            //加载边界剪切坐标
            addCutBoundsToLayer();
            //加载矢量图层
            addVectorLayer(defaluts.vectorLayerList);
            //设置中心点
            if (defaluts.center != null && defaluts.center != undefined) {
                map.getView().setCenter(defaluts.center);
            } else {
                map.getView().setCenter([94, 30]);
            }
            map.getView().setZoom(defaluts.zoom);
        }());

        /** 添加地图上的一些控件  **/
        function initMapControl() {
            //2.1显示坐标
            map.addControl(new ol.control.MousePosition({
                className: 'map_mouse-position',
                undefinedHTML: '',
                projection: 'EPSG:4326',
                coordinateFormat: function (coordinate) {
                    return ol.coordinate.format(coordinate, '{x}, {y}', 4);
                }
            }));

            //2.2添加地图缩放
            var zoomIn = me.find("#zoomIn");
            var zoomOut = me.find(".map-zoom-out");
            zoomOut.click(function () {
                var zoom = map.getView().getZoom();
                map.getView().setZoom(zoom - 1);
            });
            zoomIn.click(function () {
                var zoom = map.getView().getZoom();
                map.getView().setZoom(zoom + 1);
            });
        };

        /** 添加要素  **/
        function addFeature(feat) {
            var id = uuid();
            feat.setId(id);
            if (isSmooth && toolType != "Point" && toolType != "Circle") {
                var geometry = feat.getGeometry();
                var coords = geometry.getCoordinates();
                var smoothened = [];
                if (toolType == "Polygon") {
                    smoothened = getCurvePoints(convertToSmoothPoint(coords[0]), 0.5, 20, false);//makeSmooth(coords[0], 3);
                    geometry.setCoordinates([convertToGeometryPoint(smoothened)]);
                } else if (toolType == "LineString") {
                    smoothened = getCurvePoints(convertToSmoothPoint(coords), 0.5, 20, false);
                    geometry.setCoordinates(convertToGeometryPoint(smoothened));
                }
            }
            var style = new ol.style.Style({
                fill: new ol.style.Fill({
                    color: 'rgba(255,255,0,0.8)'
                }),
                stroke: new ol.style.Stroke({
                    color: 'rgba(0,0,255,1.0)',
                    width: 1
                }),
                image: new ol.style.Circle({
                    radius: 3,
                    stroke: new ol.style.Stroke({
                        color: 'rgba(0, 0, 0, 0.8)'
                    }),
                    fill: new ol.style.Fill({
                        color: 'rgba(255, 255, 0, 0.8)'
                    })
                })
            });
            feat.setStyle(style);
            if (toolType == "LineString") {
                style.getStroke().setWidth(lineWidth);
                //style.getStroke().setColor('rgba(255,255,0,1.0)');
            }
            featuresBak.push(feat);
            //map.removeInteraction(polyDraw);
            //polyDraw = null;
            //me.find('.map_polygon').removeClass("active").find("i").css("color", "");
        }

        /** 选中要素  **/
        function selectFeature() {
            //还原其他
            var features = vectorDrawSource.getFeatures();
            for (var i = 0; i < features.length; i++) {
                var feat = features[i];
                var style = feat.getStyle();
                style.getStroke().setLineDash(null);
            }
            clearPointLayer();
            if (!selectFeatures || selectFeatures.length <= 0) {
                return;
            }
            var isClear = true;
            for (var i = 0; i < selectFeatures.length; i++) {
                if (i != 0) {
                    isClear = false;
                }
                var feat = selectFeatures[i];
                var style = feat.getStyle();
                style.getStroke().setLineDash([10, 10]);
                //画点图层
                var geometry = selectFeatures[i].getGeometry();
                var coords = null;
                try{
                    coords = geometry.getCoordinates();
                } catch (e) {

                }
                var geoType = geometry.getType();
                if (geoType == "Polygon") {
                    addPointToPointLayer(coords[0], isClear);
                } else if (geoType == "LineString") {
                    addPointToPointLayer(coords, isClear);
                } else if (geoType == "Point") {
                    addPointToPointLayer([[coords[0], coords[1]]], isClear);
                } else if (geoType == "Circle" && geometry instanceof ol.geom.Circle) {
                    var radius = geometry.getRadius();
                    var center = geometry.getCenter();
                    addPointToPointLayer([center], isClear);
                }
            }
            map.render();
        }

        /** 重置要素  **/
        function reSet() {
            var features = vectorDrawSource.getFeatures();
            for (var i = 0; i < features.length; i++) {
                var feat = features[i];
                var style = feat.getStyle();
                style.getStroke().setLineDash(null);
            }
        }

        /** 从备份中重置**/
        function reSetFromBak() {
            vectorDrawSource.clear();
            for (var i = 0; i < featuresBak.length; i++) {
                var feat = featuresBak[i];
                var style = feat.getStyle();
                style.getStroke().setLineDash(null);
                vectorDrawSource.addFeature(featuresBak[i]);
            }
        }

        /** 移除交互类**/
        function removeInteraction() {
            if (polyDraw) {
                map.removeInteraction(polyDraw);
            }
            if (pointSelect) {
                map.removeInteraction(pointSelect);
            }
            if (polyModify) {
                map.removeInteraction(polyModify);
            }
            if (polyDrag) {
                map.removeInteraction(polyDrag);
            }
            if (boxSelect) {
                map.removeInteraction(boxSelect);
            }
            if (snapTool) {
                map.removeInteraction(snapTool);
            }
            boxSelect = null
            polyDraw = null;
            pointSelect = null;
            polyModify = null;
            polyDrag = null;
            snapTool = null;
        }

        /** 清空点的图层**/
        function clearPointLayer() {
            vectorPointSource.clear();
        }

        /** 添加自定义画的要素**/
        function addDrawDataFeatrues(featrues) {
            featuresBak = [];
            vectorDrawSource.clear();
            selectFeatures = [];
            if (!featrues || featrues.length <= 0) {
                return;
            }
            for (var i = 0; i < featrues.length; i++) {
                var feature = new ol.Feature();
                var geometry = null;
                if (featrues[i].GeoType == "Polygon") {
                    geometry = new ol.geom.Polygon();
                } else if (featrues[i].GeoType == "LineString") {
                    geometry = new ol.geom.LineString();
                } else if (featrues[i].GeoType == "Point") {
                    geometry = new ol.geom.Point();
                } 
                if (featrues[i].GeoType != "Circle") {
                    geometry.setCoordinates(featrues[i].Coordinates);
                } else {
                    var center = featrues[i].Coordinates[0];
                    var radius = featrues[i].Coordinates[1];
                    geometry = new ol.geom.Circle(center, radius);
                }
                feature.setGeometry(geometry);
                var style = new ol.style.Style({
                    fill: new ol.style.Fill({
                        color: featrues[i].FillColor
                    }),
                    stroke: new ol.style.Stroke({
                        color: featrues[i].LineColor,
                        width: featrues[i].LineWidth
                    }),
                    image: new ol.style.Circle({
                        radius: 3,
                        stroke: new ol.style.Stroke({
                            color: 'rgba(0, 0, 0, 0.8)'
                        }),
                        fill: new ol.style.Fill({
                            color: 'rgba(255, 255, 0, 0.8)'
                        })
                    })
                });
                feature.setStyle(style);
                var id = uuid();
                feature.setId(id);
                vectorDrawSource.addFeature(feature);
                featuresBak.push(feature);
            }
        }

        /** 添加自定义iTelluroLayer**/
        function addiTelluroLayer(layers) {
            if (!layers || layers.length <= 0) {
                return;
            }
            for (var i = 0; i < layers.length; i++) {
                var layer = new iTelluro().newItelluroLayer(layers[i].dataserverkey, layers[i].url, layers[i].tilesize, layers[i].zerolevelsize, layers[i].dataserverkey);
                if (!layers[i].zIndex) {
                    layer.setZIndex(10);
                } else {
                    layer.setZIndex(layers[i].zIndex);
                }
                if (layers[i].opacity) {
                    layer.setOpacity(layers[i].opacity);
                }
                layer.setZIndex(18);
                map.addLayer(layer);
            }
        }

        /** 添加点到点图层上**/
        function addPointToPointLayer(coords, isClear) {
            //点样式
            if (isClear) {
                clearPointLayer();
            }
            var stylePonit = new ol.style.Style({
                image: new ol.style.Circle({
                    radius: 4,
                    stroke: new ol.style.Stroke({
                        color: 'rgba(0, 0, 0, 0.8)'
                    }),
                    fill: new ol.style.Fill({
                        color: 'rgba(255, 0, 0, 1.0)'
                    })
                })
            });
            for (var j = 0; j < coords.length; j++) {
                var featurePonit = new ol.Feature();
                var geometryPonit = new ol.geom.Point();
                geometryPonit.setCoordinates(coords[j]);
                featurePonit.setGeometry(geometryPonit);
                featurePonit.setStyle(stylePonit);
                vectorPointSource.addFeature(featurePonit);
            }
        }

        /** 添加剪切边界到地图上**/
        function addCutBoundsToLayer() {
            if (!defaluts.boundWKT || defaluts.boundWKT.length <= 0) {
                return;
            }
            var vectorBoundSource = new ol.source.Vector({
                wrapX: false
            });
            var vectorBoundLayer = new ol.layer.Vector({
                source: vectorBoundSource,
                name: "cutLayer"
            });
            var style = new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: 'rgba(200,200,10,1.0)',
                    width: 3
                })
            });
            var wktParse = new ol.format.WKT();
            for (var i = 0; i < defaluts.boundWKT.length; i++) {
                var feature = wktParse.readFeature(defaluts.boundWKT[i]);
                feature.setStyle(style);
                vectorBoundSource.addFeature(feature);
            }
            vectorBoundLayer.setZIndex(95);
            map.addLayer(vectorBoundLayer);

        }

        /** 添加自定义矢量图层**/
        function addVectorLayer(layers) {
            if (!layers || layers.length <= 0) {
                return;
            };
            var style = new ol.style.Style({
                stroke: new ol.style.Stroke({
                    width: 2,
                    color: 'rgba(0,0,255,1.0)'
                })
            });
            for (var i = 0; i < layers.length; i++) {
                //加载geojson数据
                var geoJsonLayer = new ol.layer.Vector({
                    source: new ol.source.Vector({
                        url: layers[i].geoJsonUrl,
                        format: new ol.format.GeoJSON()
                    }),
                    style: style,
                    name: layers[i].layerName
                });
                geoJsonLayer.setZIndex(95);
                snapLayer = geoJsonLayer;
                map.addLayer(geoJsonLayer);
            };
        };

        /** 添加依附工具**/
        function addSnapTool() {
            if (!snapLayer) {
                return;
            }
            if (snapTool) {
                map.removeInteraction(snapTool);
            }
            snapTool = new ol.interaction.Snap({
                source: snapLayer.getSource()
            });
            map.addInteraction(snapTool);
        };

        /** 生成Guid **/
        function uuid() {
            var s = [];
            var hexDigits = "0123456789abcdef";
            for (var i = 0; i < 36; i++) {
                s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
            }
            s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
            s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
            s[8] = s[13] = s[18] = s[23] = "-";

            var uuid = s.join("");
            return uuid + "-InfoEarth";
        }

        /** 坐标装换 **/
        function convertToSmoothPoint(coords) {
            var resultArray = [];
            if (!coords || coords.length <= 0) {
                return resultArray;
            }

            for (var i = 0; i < coords.length; i++) {
                resultArray.push(coords[i][0]);
                resultArray.push(coords[i][1]);
            }
            return resultArray;
        }

        function convertToGeometryPoint(coords) {
            var resultArray = [];
            if (!coords || coords.length <= 0) {
                return resultArray;
            }

            for (var i = 0; i < coords.length; i += 2) {
                resultArray.push([coords[i], coords[i + 1]]);
            }
            return resultArray;
        }

        function createCircle(feature) {
            var featureC = new ol.Feature();
            var style = feature.getStyle();
            var geometry = new ol.geom.Polygon();
            var radius = feature.getGeometry().getRadius();
            var center = feature.getGeometry().getCenter();
            var coords = [];
            for (var i = 0; i < 360; i++) {
                var hudu = (2 * Math.PI / 360) * i;
                var x = radius * Math.sin(hudu) + center[0];
                var y = radius * Math.cos(hudu) + center[1];
                coords.push([x, y]);
            }
            coords.push(coords[0]);
            geometry.setCoordinates([coords]);
            featureC.setGeometry(geometry);
            featureC.setStyle(style);
            return featureC;
        }

        /** 地图事件**/
        map.on('singleclick', function (event, a) {
            //console.log(event);
            me.find('.map_set').removeClass("active").find("i").css("color", "");
            $(".map_container").find(".set_box").hide();
        });

        map.on('dblclick', function (event, a) {
            //console.log(event);
        });

        /** 对外提供的方法 **/
        me[0].ve = {
            updateSize: function () {
                map.updateSize();
            },
            getFeatrues: function () {
                clearPointLayer();
                var result = [];
                var features = vectorDrawSource.getFeatures();
                for (var i = 0; i < features.length; i++) {
                    var feat = features[i];
                    var geometry = feat.getGeometry();
                    var coords = null;
                    try {
                        coords = geometry.getCoordinates();
                    } catch (e) {

                    }
                    var geoType = geometry.getType();
                    var style = feat.getStyle();
                    var fillColor = style.getFill().getColor();
                    var lineColor = style.getStroke().getColor();
                    var lineWidth = style.getStroke().getWidth();
                    if (geoType == "Circle" && geometry instanceof ol.geom.Circle) {
                        var radius = geometry.getRadius();
                        var center = geometry.getCenter();
                        coords = [];
                        coords.push(center);
                        coords.push(radius);
                    }
                    var _icon = style.getImage();
                    var _iconProtoFn = Object.keys(_icon.constructor.prototype);
                    if (geoType == "Point" && _iconProtoFn.indexOf("getSrc") > 0) {
                        var pointIcon = style.getImage().getSrc();
                        result.push({ Coordinates: coords, GeoType: geoType, FillColor: fillColor, LineColor: lineColor, LineWidth: lineWidth, PointIcon: pointIcon });
                    } else {
                        result.push({ Coordinates: coords, GeoType: geoType, FillColor: fillColor, LineColor: lineColor, LineWidth: lineWidth });
                    }
                }
                return result;
            },
            setVEHeight: function (mapHeight) {
                me.height(mapHeight);
                me.find(".mapDiv").height(mapHeight);
            },
            addDrawDataFeatrues: function (featrues) {
                addDrawDataFeatrues(featrues);
            },
            clearDrawDataFeatrues: function () {
                vectorDrawSource.clear();
            }
        };
        return me;
    };
    //地图改变大小刷新
    $.fn.updateSize = function () {
        if (this[0].ve) {
            this[0].ve.updateSize();
        }
    };
    $.fn.getFeatrues = function () {
        if (this[0].ve) {
            return this[0].ve.getFeatrues();
        }
    };
    $.fn.setVEHeight = function (mapHeight) {
        if (this[0].ve) {
            return this[0].ve.setVEHeight(mapHeight);
        }
    };
    $.fn.addDrawDataFeatrues = function (featrues) {
        if (this[0].ve) {
            return this[0].ve.addDrawDataFeatrues(featrues);
        }
    };
    $.fn.clearDrawDataFeatrues = function () {
        if (this[0].ve) {
            return this[0].ve.clearDrawDataFeatrues();
        }
    };

})(jQuery);